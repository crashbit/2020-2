//
//  ViewController.swift
//  Tablas-MPOO
//
//  Created by Germán Santos Jaimes on 26/02/20.
//  Copyright © 2020 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    @IBOutlet weak var tabla: UITableView!
    
    var carrito: [(totalProductos: Int, nombreProducto: String, precioTotal: Double)] = []
    
    var products: [Product] = [
        Product(name: "producto 1", picture: "foto1", price: 3.45),
        Product(name: "producto 2", picture: "foto2", price: 9.90),
        Product(name: "producto 3", picture: "foto3", price: 5.50)
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return products.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        let product = products[indexPath.row]
        cell.textLabel!.text = product.name
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let indexPath = tabla.indexPathForSelectedRow
        
        let detailView  = segue.destination as! DetailViewController
        let product = products[indexPath!.row]
        detailView.productoRecibido = product
        detailView.firstView = self
    }
    
    func agregarProductos(totalProductos: Int, nombreProducto: String, precioTotal: Double){
        carrito.append((totalProductos: totalProductos, nombreProducto: nombreProducto, precioTotal: precioTotal))
        
        print(carrito.count)
        
    }


}

